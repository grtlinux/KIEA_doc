#!/bin/sh

price=100
str='It costs $'$price'? I can'\''t believe it!'  #(1)
echo $str
