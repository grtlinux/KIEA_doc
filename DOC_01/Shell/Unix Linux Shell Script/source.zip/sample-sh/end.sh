#!/bin/sh

echo "END"
# /home/user1/myapp/에 두기
