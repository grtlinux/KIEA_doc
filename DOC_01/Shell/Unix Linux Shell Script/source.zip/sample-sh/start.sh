#!/bin/sh

echo "START"
# /home/user1/myapp/에 두기
