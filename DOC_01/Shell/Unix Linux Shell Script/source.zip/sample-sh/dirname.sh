#!/bin/sh

cd "$(dirname "$0")"   #(1)

./start.sh
./end.sh
