#!/bin/sh

port=8080
nc -v -k -l $port   #(1)
